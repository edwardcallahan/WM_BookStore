
package com.bookdb;



/**
 *  Query names for service "bookdb"
 *  01/19/2012 08:22:16
 * 
 */
public class BookdbConstants {

    public final static String getDownloadByIdQueryName = "getDownloadById";

}
