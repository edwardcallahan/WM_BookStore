Main.widgets = {
	languageDialog: ["wm.DesignableDialog", {"height":212,"title":"language","width":"500px","containerWidgetId":"containerWidget","buttonBarId":"buttonBar"}, {}, {
		containerWidget: ["wm.Container", {"_classes":{"domNode":["wmdialogcontainer","MainContent"]},"autoScroll":true,"height":"100%","horizontalAlign":"left","margin":"0","padding":"5","verticalAlign":"top","width":"100%"}, {}, {
			languageLiveForm1: ["wm.LiveForm", {"alwaysPopulateEditors":true,"fitToContentHeight":true,"height":"138px","horizontalAlign":"left","liveEditing":false,"margin":"4","verticalAlign":"top"}, {"onSuccess":"languageLivePanel1.popupLiveFormSuccess"}, {
				binding: ["wm.Binding", {}, {}, {
					wire: ["wm.Wire", {"expression":undefined,"source":"languageDojoGrid.selectedItem","targetProperty":"dataSet"}, {}]
				}],
				idEditor1: ["wm.Number", {"caption":"Id","captionSize":"200px","emptyValue":"zero","formField":"id","height":"26px","required":true,"width":"100%"}, {}],
				languageEditor1: ["wm.Text", {"caption":"Language","captionSize":"200px","dataValue":"English","emptyValue":"emptyString","formField":"language","height":"26px","required":true,"width":"100%"}, {}],
				abbreviationEditor1: ["wm.Text", {"caption":"Abbreviation","captionSize":"200px","dataValue":"en","emptyValue":"emptyString","formField":"abbreviation","height":"26px","width":"100%"}, {}],
				numbooksEditor1: ["wm.Number", {"caption":"Numbooks","captionSize":"200px","emptyValue":"zero","formField":"numbooks","height":"26px","width":"100%"}, {}],
				numdownloadsEditor1: ["wm.Number", {"caption":"Numdownloads","captionSize":"200px","emptyValue":"zero","formField":"numdownloads","height":"26px","width":"100%"}, {}]
			}]
		}],
		buttonBar: ["wm.Panel", {"_classes":{"domNode":["dialogfooter"]},"border":"1,0,0,0","height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
			languageSaveButton: ["wm.Button", {"caption":"Save","margin":"4"}, {"onclick":"languageLiveForm1.saveDataIfValid"}, {
				binding: ["wm.Binding", {}, {}, {
					wire: ["wm.Wire", {"source":"languageLiveForm1.invalid","targetId":null,"targetProperty":"disabled"}, {}]
				}]
			}],
			languageCancelButton: ["wm.Button", {"caption":"Cancel","margin":"4"}, {"onclick":"languageDialog.hide"}]
		}]
	}],
	languageLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.languageLiveView1"}, {}],
	layoutBox1: ["wm.Layout", {"_classes":{"domNode":["HeaderContent"]},"height":"100%","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
		panel3: ["wm.Panel", {"height":"100%","horizontalAlign":"left","minHeight":600,"minWidth":900,"verticalAlign":"top","width":"75%"}, {}, {
			panel1: ["wm.HeaderContentPanel", {"border":"0,0,1,0","borderColor":"#333333","height":"65px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"0,10","verticalAlign":"middle","width":"100%"}, {}, {
				picture1: ["wm.Picture", {"border":"0","height":"50px","source":"lib/wm/base/widget/themes/default/images/wmLogo.png","width":"62px"}, {}],
				label3: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_20px","wm_FontSizePx_24px"]},"border":"0","caption":"VMware BookStore","height":"35px","padding":"4","width":"100%"}, {}, {
					format: ["wm.DataFormatter", {}, {}]
				}],
				panel5: ["wm.Panel", {"height":"100%","horizontalAlign":"right","verticalAlign":"middle","width":"100%"}, {}, {
					dojoMenu1: ["wm.DojoMenu", {"fullStructure":[{"label":"Help"},{"label":"About"}],"height":"24px","localizationStructure":{},"transparent":true,"width":"140px"}, {}]
				}]
			}],
			panel2: ["wm.MainContentPanel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
				tabLayers1: ["wm.TabLayers", {"borderColor":"#999999","clientBorder":"1","clientBorderColor":"#999999","headerHeight":"29px","margin":"0,2,0,2"}, {}, {
					layer1: ["wm.Layer", {"border":"1","borderColor":"#999999","caption":"Browse","horizontalAlign":"left","margin":"2,0,2,0","padding":"10","verticalAlign":"top"}, {}, {
						languageLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"source":"languageDialog","targetId":null,"targetProperty":"dialog"}, {}],
								wire1: ["wm.Wire", {"source":"languageLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
								wire2: ["wm.Wire", {"source":"languageDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
								wire3: ["wm.Wire", {"source":"languageSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
							}],
							languageDojoGrid: ["wm.DojoGrid", {"columns":[{"show":false,"id":"id","title":"Id","width":"80px","displayType":"Number","noDelete":true,"align":"right","formatFunc":""},{"show":true,"id":"language","title":"Language","width":"100%","displayType":"Text","noDelete":true,"align":"left","formatFunc":""},{"show":true,"id":"abbreviation","title":"Abbreviation","width":"100px","displayType":"Text","noDelete":true,"align":"left","formatFunc":""},{"show":true,"id":"numbooks","title":"Numbooks","width":"100px","displayType":"Number","noDelete":true,"align":"right","formatFunc":""},{"show":true,"id":"numdownloads","title":"Numdownloads","width":"100px","displayType":"Number","noDelete":true,"align":"right","formatFunc":""}],"height":"235px","margin":"4"}, {"onCellDblClick":"languageLivePanel1.popupLivePanelEdit"}, {
								binding: ["wm.Binding", {}, {}, {
									wire: ["wm.Wire", {"expression":undefined,"source":"languageLiveVariable1","targetProperty":"dataSet"}, {}]
								}]
							}],
							languageGridButtonPanel: ["wm.Panel", {"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","showing":false,"verticalAlign":"top","width":"100%"}, {}, {
								languageNewButton: ["wm.Button", {"caption":"New","margin":"4"}, {"onclick":"languageLivePanel1.popupLivePanelInsert"}],
								languageUpdateButton: ["wm.Button", {"caption":"Update","margin":"4"}, {"onclick":"languageLivePanel1.popupLivePanelEdit"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"source":"languageDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
									}]
								}],
								languageDeleteButton: ["wm.Button", {"caption":"Delete","margin":"4"}, {"onclick":"languageLiveForm1.deleteData"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"source":"languageDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
									}]
								}]
							}],
							panel4: ["wm.Panel", {"height":"205px","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"middle","width":"100%"}, {}, {
								dojoFisheye1: ["wm.DojoFisheye", {"border":"0","height":"60px","imageLabelField":"title","imageUrlField":"cover","padding":"0"}, {}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"expression":undefined,"source":"languageDojoGrid.selectedItem.books","targetProperty":"dataSet"}, {}]
									}]
								}],
								dojoChart1: ["wm.DojoChart", {"border":"0","chartType":"ClusteredColumns","padding":"4","width":"380px","xAxis":"abbreviation","yAxis":"numbooks, numdownloads"}, {}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"expression":undefined,"source":"languageLiveVariable1","targetProperty":"dataSet"}, {}]
									}]
								}]
							}]
						}]
					}],
					layer2: ["wm.Layer", {"border":"1","borderColor":"#999999","caption":"Download","horizontalAlign":"left","margin":"2,0,2,0","verticalAlign":"top"}, {}],
					layer3: ["wm.Layer", {"border":"1","borderColor":"#999999","caption":"Tab 3","horizontalAlign":"left","margin":"2,0,2,0","showing":false,"verticalAlign":"top"}, {}]
				}]
			}],
			panel6: ["wm.HeaderContentPanel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
				picture2: ["wm.Picture", {"border":"0","height":"100%","source":"lib/wm/base/widget/themes/default/images/wmSmallLogo.png","width":"24px"}, {}],
				label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"border":"0","caption":"Powered by WaveMaker","height":"100%","padding":"4"}, {}, {
					format: ["wm.DataFormatter", {}, {}]
				}],
				label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","border":"0","caption":"Copyright YOU 2012 ","height":"100%","padding":"4","width":"100%"}, {}, {
					format: ["wm.DataFormatter", {}, {}]
				}]
			}]
		}]
	}]
}